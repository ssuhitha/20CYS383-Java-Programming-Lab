package com.amrita.jpl.cys21033.ENDSEM;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;

/***
 *
 * @author Suhitha K
 * CB.EN.U4CYS21033
 *
 */
/**
 * The abstract File class represents a generic file with a name and size.
 */
abstract class File {
    private String fileName;
    private long fileSize;
    /**
     * Constructs a File object with the specified file name and size.
     *
     * @param fileName the name of the file
     * @param fileSize the size of the file in bytes
     */
    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }
    /**
     * Retrieves the name of the file.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }
    /**
     * Retrieves the size of the file in bytes.
     *
     * @return the file size
     */
    public long getFileSize() {
        return fileSize;
    }
    /**
     * Retrieves the type of the file.
     *
     * @return the file type
     */
    public abstract String getFileType();
    /**
     * Retrieves the details of the file.
     *
     * @return the file details
     */
    public abstract String getFileDetails();
}
/**
 * The Document class represents a document file with a document type.
 */
class Document extends File {
    private String documentType;
    /**
     * Constructs a Document object with the specified file name, size, and document type.
     *
     * @param fileName     the name of the document file
     * @param fileSize     the size of the document file in bytes
     * @param documentType the type of the document
     */
    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }
    /**
     * Retrieves the type of the document.
     *
     * @return the document type
     */
    public String getDocumentType() {
        return documentType;
    }
    /**
     * Retrieves the type of the file (document).
     *
     * @return the file type
     */
    public String getFileType() {
        return "Document";
    }

    /**
     * Retrieves the details of the document file.
     *
     * @return the file details
     */
    public String getFileDetails() {
        return "Name: " + getFileName() + ", Size: " + getFileSize() + " bytes, Type: " + documentType;
    }
}

/**
 * The Image class represents an image file with a resolution.
 */
class Image extends File {
    private String resolution;
    /**
     * Constructs an Image object with the specified file name, size, and resolution.
     *
     * @param fileName   the name of the image file
     * @param fileSize   the size of the image file in bytes
     * @param resolution the resolution of the image
     */
    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }
    /**
     * Retrieves the resolution of the image.
     *
     * @return the image resolution
     */
    public String getResolution() {
        return resolution;
    }
    /**
     * Retrieves the type of the file (image).
     *
     * @return the file type
     */
    public String getFileType() {
        return "Image";
    }
    /**
     * Retrieves the details of the image file.
     *
     * @return the file details
     */
    public String getFileDetails() {
        return "Name: " + getFileName() + ", Size: " + getFileSize() + " bytes, Resolution: " + resolution;
    }
}

/**
 * The Video class represents a video file with a duration.
 */
class Video extends File {
    private int duration;
    /**
     * Constructs a Video object with the specified file name, size, and duration.
     *
     * @param fileName  the name of the video file
     * @param fileSize  the size of the video file in bytes
     * @param duration  the duration of the video in seconds
     */
    public Video(String fileName, long fileSize, int duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }
    /**
     * Retrieves the duration of the video.
     *
     * @return the video duration
     */
    public int getDuration() {
        return duration;
    }
    /**
     * Retrieves the type of the file (video).
     *
     * @return the file type
     */
    public String getFileType() {
        return "Video";
    }
    /**
     * Retrieves the details of the video file.
     *
     * @return the file details
     */
    public String getFileDetails() {
        return "Name: " + getFileName() + ", Size: " + getFileSize() + " bytes, Duration: " + duration + " seconds";
    }
}

/**
 * The FileManager interface provides methods for managing files.
 */

interface FileManager {
    void addFile(File file);

    void deleteFile(String fileName);

    void saveToFile();

    void loadFromFile();

    ArrayList<File> getFiles();
}

/***
 * Implements file handling methods to save the file details to a text file and load file details from a text file.
 */
class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(File file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        File fileToRemove = null;
        for (File file : files) {
            if (file.getFileName().equals(fileName)) {
                fileToRemove = file;
                break;
            }
        }
        if (fileToRemove != null) {
            files.remove(fileToRemove);
        }
    }

    /***
     * Save the file details to a text file (20cys383.txt)
     */
    public void saveToFile() {
        try (PrintWriter writer = new PrintWriter("20cys383.txt")) {
            for (File file : files) {
                writer.println(file.getFileType() + "," + file.getFileName() + "," + file.getFileSize());
                if (file instanceof Document) {
                    writer.println(((Document) file).getDocumentType());
                } else if (file instanceof Image) {
                    writer.println(((Image) file).getResolution());
                } else if (file instanceof Video) {
                    writer.println(((Video) file).getDuration());
                }
            }
            writer.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    /***
     * Load the file details from a text file(20cys383.txt) and display them.
     */
    public void loadFromFile() {
        files.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("20cys383.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String fileType = parts[0];
                String fileName = parts[1];
                long fileSize = Long.parseLong(parts[2]);
                if (fileType.equals("Document")) {
                    String documentType = reader.readLine();
                    addFile(new Document(fileName, fileSize, documentType));
                } else if (fileType.equals("Image")) {
                    String resolution = reader.readLine();
                    addFile(new Image(fileName, fileSize, resolution));
                } else if (fileType.equals("Video")) {
                    int duration = Integer.parseInt(reader.readLine());
                    addFile(new Video(fileName, fileSize, duration));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<File> getFiles() {
        return files;
    }
}
/***
 *  allows users to interact with the file management system.
 * Include components such as text fields, buttons, and a table to display file information.
 * Implement event listeners for the buttons to perform file operations and update the table accordingly.
 */
class FileManagementSystemUI extends JFrame {
    private FileManager fileManager;
    private JTable fileTable;
    private DefaultTableModel tableModel;

    /***
     * @param fileManager user interface that allows users to interact with the file management system.
     * Include components such as text fields, buttons, and a table to display file information.
     * Implement event listeners for the buttons to perform file operations and update the table accordingly.
     *
     */
    public FileManagementSystemUI(FileManager fileManager) {
        this.fileManager = fileManager;

        setTitle("21UCYS End Semester Assignment File Manager");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();

        updateFileTable();
    }

    /***
     * I have added the required buttons for the interface
     * 5 in total but the load from file is not visible
     */
    private void initComponents() {
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new Object[]{"File Name", "File Type", "File Size"}, 0);
        fileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(fileTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton addDocumentButton = new JButton("Add Document");
        addDocumentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addDocument();
            }
        });
        buttonPanel.add(addDocumentButton);

        JButton addImageButton = new JButton("Add Image");
        addImageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addImage();
            }
        });
        buttonPanel.add(addImageButton);

        JButton addVideoButton = new JButton("Add Video");
        addVideoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addVideo();
            }
        });
        buttonPanel.add(addVideoButton);

        JButton deleteFileButton = new JButton("Delete File");
        deleteFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteFile();
            }
        });
        buttonPanel.add(deleteFileButton);
        JButton displayFilesButton = new JButton("Refresh");
        displayFilesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayFiles();
            }
        });
        buttonPanel.add(displayFilesButton);
        JButton loadFromFileButton = new JButton("Load from file");
        loadFromFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadFromFile();
            }
        });
        buttonPanel.add(loadFromFileButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(mainPanel);
    }

    private void updateFileTable() {
        tableModel.setRowCount(0);
        for (File file : fileManager.getFiles()) {
            tableModel.addRow(new Object[]{file.getFileName(), file.getFileType(), file.getFileSize()});
        }
    }
    /***
     * Adds a document by entering the document name, size, and type.
     *
     */
    private void addDocument() {
        String fileName = JOptionPane.showInputDialog(this, "Enter Document Name:");
        long fileSize = Long.parseLong(JOptionPane.showInputDialog(this, "Enter Document Size (in bytes):"));
        String documentType = JOptionPane.showInputDialog(this, "Enter Document Type:");
        File document = new Document(fileName, fileSize, documentType);
        fileManager.addFile(document);
        updateFileTable();
    }

    /***
     * Adds an image by entering the image name, size, and resolution.
     */
    private void addImage() {
        String fileName = JOptionPane.showInputDialog(this, "Enter Image Name:");
        long fileSize = Long.parseLong(JOptionPane.showInputDialog(this, "Enter Image Size (in bytes):"));
        String resolution = JOptionPane.showInputDialog(this, "Enter Image Resolution:");
        File image = new Image(fileName, fileSize, resolution);
        fileManager.addFile(image);
        updateFileTable();
    }

    /***
     * Adds a video by entering the video name, size, and duration.
     */
    private void addVideo() {
        String fileName = JOptionPane.showInputDialog(this, "Enter Video Name:");
        long fileSize = Long.parseLong(JOptionPane.showInputDialog(this, "Enter Video Size (in bytes):"));
        int duration = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Video Duration (in seconds):"));
        File video = new Video(fileName, fileSize, duration);
        fileManager.addFile(video);
        updateFileTable();
    }

    /***
     * Deletes a file by selecting it from the displayed list.
     */
    private void deleteFile() {
        int selectedRow = fileTable.getSelectedRow();
        if (selectedRow != -1) {
            String fileName = (String) tableModel.getValueAt(selectedRow, 0);
            fileManager.deleteFile(fileName);
            updateFileTable();
        } else {
            JOptionPane.showMessageDialog(this, "No file selected.", "Delete File", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void displayFiles() {
        updateFileTable();
    }

    /***
     * Saves the added details to 20cys383.txt
     */
    private void saveToFile() {
        fileManager.saveToFile();
        JOptionPane.showMessageDialog(this, "File details saved to file.", "Save to File", JOptionPane.INFORMATION_MESSAGE);
    }

    /***
     * Loads from 20cys383.txt
     */
    private void loadFromFile() {
        fileManager.loadFromFile();
        updateFileTable();
        JOptionPane.showMessageDialog(this, "File details loaded from file.", "Load from File", JOptionPane.INFORMATION_MESSAGE);
    }
}


public class Main {
    public static void main(String[] args) {
        FileManager fileManager = new FileManagerImpl();
        FileManagementSystemUI fileManagementSystemUI = new FileManagementSystemUI(fileManager);
        fileManagementSystemUI.setVisible(true);
    }
}
/*

To read from the file file_details.txt
public class FileDetailsReader {
    public static void main(String[] args) {
        try
                System.out.println(line);
            }
        } catch (IOException e) {

        }
    }
}

 */