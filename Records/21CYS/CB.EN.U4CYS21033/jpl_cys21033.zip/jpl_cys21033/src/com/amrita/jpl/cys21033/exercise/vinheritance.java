package com.amrita.jpl.cys21033.exercise;
/**
 * @author Suhitha K
 * @param vinheritace  class in java evaluation
 * @return
 * @version 0.5
 */
class Vehicle {
    boolean run_status;

    public void start() {
        run_status = true;
        System.out.println("[Vehicle] started.");

    }


    public void stop() {
        run_status = false;
        System.out.println("[Vehicle] stopped.");
    }

}


class Car extends Vehicle {
    String model_name;
    int year, num_wheels;

    public Car(String model_name, int year, int num_wheels) {
        this.model_name = model_name;
        this.year = year;
        this.num_wheels = num_wheels;
    }
    System.out.println("Car Instantiated with Parameter"+model_name+","+year+","+num_wheels);
    public void drive(int gear_position) {
        if(run_status) {
            System.out.println("Driving the car in gear position: " + gear_position);
        } else {
            System.out.println("Error: Car is not running.");
        }

    }
}

class Bike extends Vehicle {
    String brand_name;
    int year, num_gears;

    public Bike(String brand_name, int year, int num_gears) {
        this.brand_name = brand_name;
        this.year = year;
        this.num_gears = num_gears;
    }
        System.out.println("Bike Instantiated with Parameter"+brand_name+","+year+","+num_gears);

    public void pedal(int pedal_speed) {
        if(run_status) {
            System.out.println("Pedaling the bike at speed: " + pedal_speed);
        } else {
            System.out.println("Error: Bike is not running.");
        }
    }
}

public class vinheritance {

    public static void main(String[] args) {

        Car my_car = new Car("Jaguar XF", 2022, 4);
        Bike my_bike = new Bike("Giant", 2021, 18);

        my_car.start();
        my_car.drive(3);

        my_car.stop();

        my_bike.start();
        my_bike.pedal(10);

        my_bike.stop();

    }

}