package com.amrita.jpl.cys21033.pract;
/**
 * @author Suhitha K
 * @param //Adding numbers in java
 * @version 0.5
 *
 */
public class Addition {

        public static void main(String[] args) {
            System.out.println("Addition of two numbers");
            int j = 4;
            int k =3;
            int l=j+k;
            System.out.println(l);
        }

}
